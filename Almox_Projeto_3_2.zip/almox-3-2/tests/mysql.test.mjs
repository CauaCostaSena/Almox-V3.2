import test from "node:test";
import assert from "node:assert/strict";
import { createPool } from "../server/db.mjs";
import {
  saveStock,
  readStock,
  register,
  login,
  sessionUser,
  saveAdmin,
  readAdmin,
  updateAges,
} from "../server/service.mjs";
if (!process.env.DB_NAME?.endsWith("_testes"))
  throw Error("Use somente uma base terminada em _testes.");
import { ageAt } from "../lib/rules.ts";
import { today } from "../server/auth.mjs";
const pool = createPool();
let admin, product, user;
test.before(async () => {
  const [r] = await pool.query(
    "SELECT * FROM usuarios WHERE email='admin@almox.est'",
  );
  admin = r[0];
  await pool.query("DELETE FROM movimentacoes");
  await pool.query("DELETE FROM auditoria_admin");
  await pool.query("DELETE FROM produtos");
  await pool.query("DELETE FROM usuarios WHERE conta_sistema=0");
});
test.after(() => pool.end());
test("TI01 persistência em reais, chave estrangeira e autenticação", async () => {
  await saveStock(
    pool,
    {
      action: "produto",
      nome: "Produto de teste",
      preco: "R$20,00",
      quantidade: 10,
    },
    admin,
  );
  const stock = await readStock(pool);
  product = stock.products[0];
  assert.equal(product.preco, "20.00");
  assert.equal(stock.movements[0].alvo_nome, "Produto de teste");
  await assert.rejects(
    pool.query(
      "INSERT INTO sessoes VALUES('invalido','inexistente',UTC_TIMESTAMP())",
    ),
  );
  const { token } = await login(pool, {
    email: admin.email,
    senha: "admin$777",
  });
  assert.equal((await sessionUser(pool, token)).nome, "Administrador");
});
test("TI02 falha real de INSERT desfaz atualização do saldo", async () => {
  await pool.query(
    "CREATE TRIGGER almox_test_fail BEFORE INSERT ON movimentacoes FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='falha induzida no histórico'",
  );
  try {
    await assert.rejects(
      saveStock(
        pool,
        { action: "movimentar", id: product.id, tipo: "saida", quantidade: 3 },
        admin,
      ),
    );
    const s = await readStock(pool);
    assert.equal(s.products[0].quantidade, 10);
    assert.equal(s.movements.length, 1);
  } finally {
    await pool.query("DROP TRIGGER almox_test_fail");
  }
});
test("TI03 concorrência, edição reversível e exclusão com nome preservado", async () => {
  const results = await Promise.allSettled(
    [1, 2].map(() =>
      saveStock(
        pool,
        { action: "movimentar", id: product.id, tipo: "saida", quantidade: 7 },
        admin,
      ),
    ),
  );
  assert.equal(results.filter((x) => x.status === "fulfilled").length, 1);
  assert.equal((await readStock(pool)).products[0].quantidade, 3);
  await saveStock(
    pool,
    { action: "editar", id: product.id, nome: "Produto novo", preco: "30,00" },
    admin,
  );
  let s = await readStock(pool);
  assert.equal(s.products[0].nome, "Produto novo");
  await saveStock(pool, { action: "reverter", id: s.movements[0].id }, admin);
  assert.equal((await readStock(pool)).products[0].nome, "Produto de teste");
  await saveStock(pool, { action: "excluir", id: product.id, senha_exclusao: "#DeleAll42" }, admin);
  s = await readStock(pool);
  assert.equal(s.products.length, 0);
  assert.equal(s.movements[0].alvo_nome, "Produto de teste");
  assert.equal(s.movements[0].usuario_nome, "Administrador");
  assert.equal(s.movements[0].alvo_id, null);
});
test("TI04 funcionário, auditoria, reversão, idade e revogação da sessão", async () => {
  const data = {
    nome: "Maria Silva",
    cpf: "52998224725",
    telefone: "11999999999",
    email: "maria@almox.est",
    nascimento: "2000-01-01",
    cargo: "Estoquista",
    pais: "BR",
    estado: "BA",
    cidade: "Salvador",
    bairro: "Centro",
    senha: "senha123",
  };
  await register(pool, data);
  user = (await readAdmin(pool)).users.find((u) => u.email === data.email);
  assert.equal(user.perfil, "funcionario");
  const { token } = await login(pool, data);
  await assert.rejects(
    saveAdmin(pool, { action: "excluir", id: admin.id }, user),
  );
  await saveAdmin(
    pool,
    { ...data, action: "editar", id: user.id, nome: "Maria Souza" },
    admin,
  );
  let a = await readAdmin(pool);
  assert.equal(a.users.find((u) => u.id === user.id).nome, "Maria Souza");
  await saveAdmin(pool, { action: "reverter", id: a.events[0].id }, admin);
  assert.equal(
    (await readAdmin(pool)).users.find((u) => u.id === user.id).nome,
    "Maria Silva",
  );
  await pool.execute("UPDATE usuarios SET idade=16 WHERE id=?", [user.id]);
  await updateAges(pool);
  assert.equal(
    (await readAdmin(pool)).users.find((u) => u.id === user.id).idade,
    ageAt("2000-01-01", today()),
  );
  await saveStock(
    pool,
    { action: "produto", nome: "Produto Maria", preco: "0,01", quantidade: 0 },
    user,
  );
  await saveAdmin(pool, { action: "excluir", id: user.id }, admin);
  assert.equal(await sessionUser(pool, token), null);
  assert.equal(
    (await readStock(pool)).movements[0].usuario_nome,
    "Maria Silva",
  );
  await assert.rejects(
    saveAdmin(pool, { action: "excluir", id: admin.id }, admin),
  );
});
